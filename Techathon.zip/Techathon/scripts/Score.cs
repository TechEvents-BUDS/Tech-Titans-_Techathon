using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    private float forwardforce = 17f;
    private float distanceTraveled = 0;
    [SerializeField]
    private TextMeshProUGUI scoreText;
    public int score;

    public GameObject player;
    bool isGameOver = false;
    private void Start()
    {
        scoreText = GetComponent<TextMeshProUGUI>();
    }

    void Update()
    {
        if(player !=null &!isGameOver)
        {
        distanceTraveled += Time.deltaTime* forwardforce;
            score = Mathf.FloorToInt(distanceTraveled);
            scoreText.text = "Score: " + score;
        }
    }
}
