using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class GeminiApi : MonoBehaviour
{
    // The Gemini API URL (replace with the actual API URL for text-to-speech)
    private string apiUrl = "https://ai.google.dev/competition/projects/text-to-speech"; // Replace with the correct URL if needed

    // Method to send the text to Gemini API for speech
    public IEnumerator Speak(string textToSpeak)
    {
        // JSON body for the POST request
        string json = "{\"text\":\"" + textToSpeak + "\"}";
        byte[] jsonToSend = new System.Text.UTF8Encoding().GetBytes(json);

        // Create a UnityWebRequest to call the API
        UnityWebRequest request = new UnityWebRequest(apiUrl, "POST")
        {
            uploadHandler = new UploadHandlerRaw(jsonToSend),
            downloadHandler = new DownloadHandlerBuffer()
        };

        // Set the appropriate headers
        request.SetRequestHeader("Content-Type", "application/json");
        request.SetRequestHeader("Authorization", "Bearer AIzaSyDPvaJTGIZ05tB7HOjaxJlJXa7-f6hWLF4"); // Your actual API key

        // Send the request and wait for the response
        yield return request.SendWebRequest();

        // Check if there was an error
        if (request.result != UnityWebRequest.Result.Success)
        {
            // If there is an error, log it
            Debug.LogError("Error: " + request.error);
        }
        else
        {
            Debug.Log("Successfully sent text to speech API!");
            Debug.Log("Response: " + request.downloadHandler.text); // Optionally log the response
        }
    }

    // Method to announce the Game Over message (score, coins, and time)
    public void AnnounceGameOver(int score, int coins, float elapsedTime)
    {
        // Format the time to minutes and seconds
        int minutes = Mathf.FloorToInt(elapsedTime / 60);
        int seconds = Mathf.FloorToInt(elapsedTime % 60);
        string formattedTime = string.Format("{0:00}:{1:00}", minutes, seconds);

        // Construct the message to be spoken
        string message = $"Congratulations! You scored {score} points, collected {coins} coins, and your time was {formattedTime}.";

        // Start the coroutine to send the message to the Gemini API for speech synthesis
        StartCoroutine(Speak(message));
    }
}
