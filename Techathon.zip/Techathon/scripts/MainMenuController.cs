using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    public void playGame()
    {
        SceneManager.LoadScene("GamePlay");
       
    }

    public void QuitGame() 
    { 
        Application.Quit();
        Debug.Log("Game is Ended");
    }
  
}
