using Unity.VisualScripting;
using UnityEngine;
public class player : MonoBehaviour
{
    private float moveforce = 10f;
    private float forwardforce = 17f;
    //bool isgrounded = false;
    [SerializeField] private GameObject gameOverWindow;
   
    private Rigidbody mybody;

   

    void Start()
    {
        mybody = GetComponent<Rigidbody>();
        gameOverWindow.SetActive(false);
      
    }

    void Update()
    {
        move();
    }

    void OnCollisionEnter(Collision collision)
    {

        if (collision.gameObject.CompareTag("Obstacles"))
        {
            Destroy(gameObject);
            gameOverWindow.SetActive(true);
            FindFirstObjectByType<Timer>().StopTimer();
            int scoreText = FindFirstObjectByType<Score>().score;
            int coinsText = FindFirstObjectByType<Coins>().playerCoins;
            float timeText = FindFirstObjectByType<Timer>().elapsedTime;
            FindFirstObjectByType<GameOverWindow>().GameOver(scoreText, coinsText);
            FindFirstObjectByType<GeminiApi>().AnnounceGameOver(scoreText, coinsText, timeText);
          
        }
    }


    public void move()
    {
        float horizontal = 0;
       
        if(Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow ))
        {
            horizontal = 1;
        }
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            horizontal = -1;
        }

        Vector3 movement = new Vector3(horizontal * moveforce, 0, forwardforce) * Time.deltaTime;

        // Use Rigidbody for movement
        mybody.MovePosition(transform.position + movement);
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            Coins coinIncrease = FindFirstObjectByType<Coins>();
            coinIncrease.coinIncrease();
        }
        Destroy(other.gameObject);
    }


}